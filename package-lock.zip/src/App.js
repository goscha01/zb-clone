import logo from './logo.svg';
import './App.css';
import './index.css'
import HomePage from './app/page';

export default function App() {
  return (
    <HomePage />
  );
}

